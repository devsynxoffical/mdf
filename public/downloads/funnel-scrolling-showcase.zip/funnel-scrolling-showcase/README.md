# 📜 Auto-Scrolling Webpage / Funnel Showcase Section

An award-winning, tactile 3D auto-scrolling showcase section for presenting full-length websites, landing pages, and sales funnels.

---

## 🌟 Key Features
- **Smooth Auto-Pan Animation**: Auto-scrolls from the top of the webpage screenshot down to the footer, pauses at key sections, and alternates back up.
- **Hover to Pause & Inspect**: Automatically pauses on hover so users can comfortably read the content.
- **IntersectionObserver Optimization**: Animation only runs when in viewport to ensure 60fps performance and zero idle CPU usage.
- **3D Tactile Book-Page Effects**:
  - Book spine crease on the left.
  - Top & bottom rolled paper shadows.
  - Folded dog-ear corner fold at top-right.
  - Subtle diagonal glass shimmer sweep.
  - Stacked page layers underneath (`book-page-frame`).
- **8 Full-Length High-Res Funnel Screenshots** included (`funnel-01.webp` through `funnel-08.webp`).

---

## 📁 Package Structure

```
funnel-scrolling-showcase/
├── standalone-demo.html         <- Open directly in any browser to see it working!
├── README.md                    <- This documentation guide
├── css/
│   └── funnel-scroll.css        <- Pure CSS keyframes & tactile styles
├── components/
│   ├── FunnelScrollBlock.tsx    <- React/Next.js single scrolling viewport component
│   └── FunnelScrollSection.tsx  <- React/Next.js 2-column showcase grid with GSAP entry
└── images/
    ├── funnel-01.webp           <- Mortgage AI System
    ├── funnel-02.webp           <- Rowan Security
    ├── funnel-03.webp           <- Love My Invention
    ├── funnel-04.webp           <- Pluto CRM
    ├── funnel-05.webp           <- Bio-Optimization VSL
    ├── funnel-06.webp           <- Growth Foundry
    ├── funnel-07.webp           <- Stealth AI Agency
    └── funnel-08.webp           <- High-Ticket Coaching
```

---

## 🚀 How to Add to Any Website

### Option A: Plain HTML & CSS (WordPress, Webflow, Shopify, Vanilla)
1. Copy `css/funnel-scroll.css` into your project.
2. Put the images from `images/` into your public images folder.
3. Use this HTML snippet for each card:
```html
<div class="funnel-screen-viewport book-page-frame" style="--funnel-dur: 15s;">
  <div class="spine-crease"></div>
  <div class="paper-roll-top"></div>
  <div class="paper-roll-bottom"></div>
  <div class="dog-ear"><div class="dog-ear-curl"></div></div>
  <img class="funnel-auto-scroll" src="images/funnel-01.webp" alt="Website preview">
  <div class="live-scroll-badge">
    <span class="live-scroll-dot"></span>
    <span>Page Scroll</span>
  </div>
</div>
```
4. Include the lightweight script at the bottom of your page:
```javascript
const viewports = document.querySelectorAll(".funnel-screen-viewport");
viewports.forEach((el) => {
  el.style.setProperty("--viewH", el.clientHeight + "px");
});
const observer = new IntersectionObserver((entries) => {
  entries.forEach((e) => e.target.classList.toggle("is-inview", e.isIntersecting));
}, { threshold: 0.15 });
viewports.forEach((el) => observer.observe(el));
```

### Option B: React & Next.js
1. Copy `components/FunnelScrollBlock.tsx` into your `components/` directory.
2. Add the styles from `css/funnel-scroll.css` to your global CSS (or `globals.css`).
3. Place the images in `/public/images/funnels/`.
4. Import and use:
```tsx
import FunnelScrollBlock from "@/components/FunnelScrollBlock";

<FunnelScrollBlock
  src="/images/funnels/funnel-01.webp"
  duration={14}
  label="Mortgage AI System"
/>
```

---

## 🎨 How to Customize the Scroll Speed
Each card accepts a CSS variable `--funnel-dur`:
- Faster scroll: `--funnel-dur: 10s;`
- Slower, relaxed scroll for long sales letters: `--funnel-dur: 20s;`
